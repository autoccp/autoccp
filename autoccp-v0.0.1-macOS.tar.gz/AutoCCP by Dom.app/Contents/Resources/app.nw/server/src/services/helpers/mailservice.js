'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var randexp = require('randexp');
var promisify = require("es6-promisify");
var nodemailer = require('nodemailer');

module.exports = function (app) {
  var MailService = function () {
    function MailService() {
      _classCallCheck(this, MailService);
    }

    // POST


    _createClass(MailService, [{
      key: 'create',
      value: function create(_ref, params) {
        var email = _ref.email,
            subject = _ref.subject,
            content = _ref.content;

        var transporter = nodemailer.createTransport(app.get("secrets").smtp);
        var sendMail = promisify(transporter.sendMail, transporter);
        return sendMail({
          from: 'noreply@schul-cloud.org',
          to: email,
          subject: subject,
          html: content.html,
          text: content.text
        });
      }
    }]);

    return MailService;
  }();

  return MailService;
};