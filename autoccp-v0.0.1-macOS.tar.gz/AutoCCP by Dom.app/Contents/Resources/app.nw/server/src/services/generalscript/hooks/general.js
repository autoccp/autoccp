'use strict';

var webdriverio = require('webdriverio');
var nedb = require('nedb');
var path = require('path');
var url1 = '/finance/jgz-take-digit';
var url2 = '/finance/jgz-take-general';

var URL = 'https://www.ccp100.com';
var min_balance = 100;
var min_purchasecoin = 1;

function sellWallet(client, URL, array, url, pin, gold) {

  console.log("SELLING MY WALLET" + URL + url + " " + pin + " " + array + " " + gold);
  if (gold == "1" || gold == "2") {
    array = "1000";
  }
  if (gold == "3" || gold == "4") {
    array = "3000";
  }
  if (gold == "5" || gold == "6") {
    array = "5000";
  }
  if (gold == "7") {
    array = "7000";
  }
  return client.url(URL + url).selectByValue('#TradeWay', '2').setValue('#GuoZi', array).setValue('#PasswordTrade', pin).click('#btnSave').waitForVisible('.ui_title_bar', 2000)
  // .alertAccept()
  .click('body > div:nth-child(1) > table > tbody > tr:nth-child(2) > td.ui_c > div > table > tbody > tr:nth-child(3) > td > div > input.btn.btn-default.btn-primary');
}

function captcha(client, cap) {
  "use strict";

  var datavalue;
  if (cap == "Apple") {
    datavalue = 5;
  }
  if (cap == "Ariel") {
    datavalue = 6;
  }
  if (cap == "Bear") {
    datavalue = 10;
  }
  if (cap == "Boat") {
    datavalue = 11;
  }
  if (cap == "Bulb") {
    datavalue = 35;
  }
  if (cap == "Baseball") {
    datavalue = 8;
  }
  if (cap == "Chicken") {
    datavalue = 17;
  }
  if (cap == "Cat") {
    datavalue = 14;
  }
  if (cap == "Camel") {
    datavalue = 12;
  }
  if (cap == "Candy") {
    datavalue = 13;
  }
  if (cap == "Clock") {
    datavalue = 18;
  }
  if (cap == "Cricket") {
    datavalue = 19;
  }
  if (cap == "Chair") {
    datavalue = 15;
  }
  if (cap == "Cherry") {
    datavalue = 16;
  }
  if (cap == "Dress") {
    datavalue = 22;
  }
  if (cap == "Drum") {
    datavalue = 23;
  }
  if (cap == "Duck") {
    datavalue = 24;
  }
  if (cap == "Diamond") {
    datavalue = 20;
  }
  if (cap == "Elephant") {
    datavalue = 25;
  }
  if (cap == "Eagle") {
    datavalue = 7;
  }
  if (cap == "Excavator") {
    datavalue = 26;
  }
  if (cap == "Fish") {
    datavalue = 27;
  }
  if (cap == "Flute") {
    datavalue = 28;
  }
  if (cap == "Flower") {
    datavalue = 39;
  }
  if (cap == "Football") {
    datavalue = 9;
  }
  if (cap == "Headphone") {
    datavalue = 30;
  }
  if (cap == "House") {
    datavalue = 32;
  }
  if (cap == "Horse") {
    datavalue = 31;
  }
  if (cap == "Gear") {
    datavalue = 29;
  }
  if (cap == "Lion") {
    datavalue = 36;
  }
  if (cap == "Lollipop") {
    datavalue = 37;
  }
  if (cap == "Kangaroo") {
    datavalue = 33;
  }
  if (cap == "Key") {
    datavalue = 34;
  }
  if (cap == "Plane") {
    datavalue = 1;
  }
  if (cap == "SUV") {
    datavalue = 0;
  }
  if (cap == "Saxophone") {
    datavalue = 38;
  }
  if (cap == "Scissor") {
    datavalue = 4;
  }
  if (cap == "Shoes") {
    datavalue = 21;
  }
  if (cap == "T-Shirt") {
    datavalue = 2;
  }
  if (cap == "Watch") {
    datavalue = 3;
  }
  return client.click('[data-index="' + datavalue + '"]');
}

module.exports = function (options) {
  //options = Object.assign({}, defaults, options);
  console.log('options');

  return function (hook, next) {
    var accounts = new nedb({
      filename: path.join(hook.app.get('nedb'), 'accounts.db'),
      autoload: true
    });
    var weboptions = {
      desiredCapabilities: {
        browserName: 'chrome',
        loggingPrefs: {
          performance: 'ALL'
        },
        chromeOptions: {
          perfLoggingPrefs: {
            enableNetwork: true,
            traceCategories: "v8"
          }
        }

      },
      logLevel: 'verbose'
    };
    var client = webdriverio.remote(weboptions);

    var username = hook.data.username;
    var pin = hook.data.pincode;
    var password = hook.data.password;
    var goldstar = hook.data.goldstar;
    var bonuswallet = hook.data.bonuswallet;
    var cashwallet = hook.data.cashwallet;
    var centseed = hook.data.centseed;
    var centroot = hook.data.centroot;
    var centcoin = hook.data.centcoin;
    var centfruit = hook.data.centfruit;
    var centfruitpending = hook.data.centfruitpending;
    var centfruitpercentage = hook.data.centfruitpercentage;
    var centfruitnumber = hook.data.centfruitnumber;

    console.log(username + password + pin + goldstar + centseed + centfruitnumber);
    console.log("START");
    var gold = accounts.findOne({ username: username }, function (err, doc) {
      return doc.gold;
    });

    client.init()
    /* LOGIN */
    .url(URL + '/site/login?id=' + username + '&safe=0').waitForExist('#divVerifyPics', 6000).waitForText('#spanVerifyName', 2000).setValue('#Password', password).getText('#spanVerifyName').then(function (cap) {
      return captcha(client, cap);
    }).click('#login-button').then(function () {
      /***** Gold Level ****/
      if (goldstar == true) {
        console.log("gold start here");
        return client.url(URL + '/profile/info').setValue('#PasswordTrade', pin).click('#btnSubmit').pause(1000).url(URL + '/profile/info').waitForValue('#Lang', 2000).getText('#formData > fieldset:nth-child(2) > div:nth-child(3) > div > div > p', false).then(function (value) {
          if (value == 'None') {
            return accounts.update({ username: username }, {
              $set: {
                gold: 0
              }
            });
          } else {
            return client.getAttribute('#formData > fieldset:nth-child(2) > div:nth-child(3) > div > div > p > img', 'src').then(function (attr) {
              gold = attr.substring(attr.lastIndexOf('/') + 1).replace(/\.[^/.]+$/, "");
              accounts.update({ username: username }, {
                $set: {
                  gold: gold
                }
              });
            });
          }
        });
      }
    }).then(function () {
      //***** NEEDS FIX *****/
      if (bonuswallet == true || cashwallet == true) {
        return client.url(URL + '/finance/jgz-take').waitForValue('.jumbotron', 1000).getText('.jumbotron h2').then(function (res) {
          var array = [];
          res.forEach(function (element) {
            var hTwo = element.replace(/\$/g, '').replace(/\,/g, '');
            hTwo = parseFloat(hTwo);
            array.push(hTwo);
          });
          return array;
        }).then(function (array) {
          return accounts.update({ username: username }, {
            $set: {
              wallet: {
                digital: array[0],
                cash: array[1]
              }
            }
          });
        }).call(function () {
          return new Promise(function (resolve, reject) {
            accounts.findOne({ username: username }, function (err, doc) {
              resolve(doc.wallet.digital);
            });
          });
        }).then(function (array) {
          console.log("I am here 2", array);
          if (bonuswallet == true) {
            if (array > min_balance) {
              console.log("MIN BALANCE OF BONUS ACCOUNT IS ", array);
              return sellWallet(client, URL, array, url1, pin, goldstar);
            } else {
              return array;
            }
          }
        }).call(function () {
          return new Promise(function (resolve, reject) {
            accounts.findOne({ username: username }, function (err, doc) {
              resolve(doc.wallet.cash);
            });
          });
        }).then(function (array) {
          console.log("I am here");
          if (cashwallet == true) {

            console.log("I am here 4", array);
            if (array > min_balance) {

              console.log("BALANCE OF CASH ACCOUNT IS ", array);
              return sellWallet(client, URL, array, url2, pin, goldstar);
            } else {
              return array;
            }
          }
        });
      }
    }).then(function () {
      if (centroot || centseed) {
        return client.url(URL + '/trade/jsy-buy');
      }
    }).then(function () {
      if (centseed) {
        return client.selectByValue('#PayType', '0').getText('#spanKy').then(function (value) {
          if (value > min_purchasecoin) {
            return client.setValue('#PasswordTrade', pin).click('#btnSave');
          }
        });
      }
    }).then(function () {
      if (centroot) {
        return client.selectByValue('#PayType', '1').getText('#spanKy').then(function (value) {
          if (value > min_purchasecoin) {
            return client.setValue('#PasswordTrade', pin).click('#btnSave');
          }
        });
      }
    }).then(function () {
      if (centcoin) {
        return client.url(URL + '/finance/my').getValue('body > div.bg_temp_b > div > div:nth-child(3) > div.form-horizontal > fieldset:nth-child(3) > div > div > div:nth-child(2) > input').then(function (val) {
          accounts.update({ username: username }, {
            $set: {
              centcoin: val
            }
          });
        });
      }
    })

    /******** PURCHASE CHECKER *****/
    /******* DOESN't WORK FORMORE THAN 1******/
    .url(URL + '/finance/jzz-progress?state=0').waitForValue('body > div.bg_temp_b > div > div:nth-child(3) > div.tab-content > table > tbody > tr:nth-child(2) > td:nth-child(1)', 3000).isExisting('body > div.bg_temp_b > div > div:nth-child(3) > div.tab-content > table > tbody > tr:nth-child(2) > td:nth-child(2)').then(function (val) {

      if (val) {
        return client.getText('body > div.bg_temp_b > div > div:nth-child(3) > div.tab-content > table > tbody > tr:nth-child(2) > td:nth-child(1)').then(function (serial) {
          return client.getText('body > div.bg_temp_b > div > div:nth-child(3) > div.tab-content > table > tbody > tr:nth-child(2) > td:nth-child(2)').then(function (centseed) {
            return client.getText('body > div.bg_temp_b > div > div:nth-child(3) > div.tab-content > table > tbody > tr:nth-child(2) > td:nth-child(7)').then(function (date) {
              //console.log("THIS IS THE CENTCOIN + DATE", centseed, date, serial);

              if (serial instanceof Array) {
                /*async.each(centseed, serial, date, function(seed,ser,time, callback) {
                 console.log("THIS IS THE CENSDJSAKDSAJKDSHAK", seed, time, ser);
                 seed = seed.replace(/\$/g, '');
                  var purchasing = {};
                 purchasing[ser] = {
                 'total': seed,
                 'date': time
                 };
                 accounts.update({username: username}, {
                 $set: {
                 purchasing
                 }
                 });
                 }, function(err, result) {
                 // if result is true then every file exists
                 }); */
                for (var i = 0; i < serial.length; ++i) {

                  centseed[i] = centseed[i].replace(/\$/g, '');

                  var purchasing = {};
                  purchasing[serial[i]] = {
                    'total': centseed[i],
                    'date': date[i]
                  };
                  console.log("THIS IS THE CENSDJSAKDSAJKDSHAK", centseed[i], date[i], serial[i]);
                  accounts.update({ username: username }, {
                    $set: {
                      purchasing: purchasing
                    }
                  });
                }
              } else {
                centseed = centseed.replace(/\$/g, '');

                var purchasing = {};
                purchasing[serial] = {
                  'total': centseed,
                  'date': date
                };
                accounts.update({ username: username }, {
                  $set: {
                    purchasing: purchasing
                  }
                });
              }
            });
          });
        });
      }
    }).end().then(function () {
      accounts.persistence.compactDatafile(); // compact DB
      console.log('All accounts have been processed successfully');
      hook.data = {
        success: 'success'
      };
      next();
    });
  };
};