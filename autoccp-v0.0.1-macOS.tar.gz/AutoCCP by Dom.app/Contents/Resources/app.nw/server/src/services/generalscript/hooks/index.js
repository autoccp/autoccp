'use strict';

var globalHooks = require('../../../hooks');
var general = require('./general');
var hooks = require('feathers-hooks');
var format = require('./format');

var myDebugHook = function myDebugHook(hook) {
  // check to see what is in my hook object after
  // the token was verified.
  console.log(hook.data);
};
exports.before = {
  all: [myDebugHook],
  find: [],
  get: [],
  create: [general()],
  update: [],
  patch: [],
  remove: []
};

exports.after = {
  all: [format("data")],
  find: [],
  get: [],
  create: [],
  update: [],
  patch: [],
  remove: []
};