'use strict';

// src/services/accounts/hooks/create.js
//
// Use this hook to manipulate incoming or outgoing data.
// For more information on hooks see: http://docs.feathersjs.com/hooks/readme.html

var defaults = {};

module.exports = function (options) {
  options = Object.assign({}, defaults, options);

  return function (hook) {
    var username = hook.params.query.username;
    hook.data = {
      username: username
    };
    return hook;
  };
};