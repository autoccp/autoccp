'use strict';

var globalHooks = require('../../../hooks');
var hooks = require('feathers-hooks');
var common = require('feathers-hooks-common');
var format = require('./format');

var myDebugHook = function myDebugHook(hook) {
  // check to see what is in my hook object after
  // the token was verified.
  console.log(hook);
};

exports.before = {
  all: [myDebugHook],
  find: [],
  get: [],
  create: [function (hook) {
    hook.data.createdAt = new Date();
    hook.data.setUpdatedAt = new Date();
  }],
  update: [common.setUpdatedAt()],
  patch: [common.setUpdatedAt()],
  remove: []
};

exports.after = {
  all: [format("data")],
  find: [],
  get: [],
  create: [],
  update: [],
  patch: [],
  remove: []
};