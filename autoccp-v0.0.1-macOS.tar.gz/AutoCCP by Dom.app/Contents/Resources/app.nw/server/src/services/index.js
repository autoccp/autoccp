'use strict';

var clients = require('./clients');
var generalscript = require('./generalscript');
var accounts = require('./accounts');
var authentication = require('./authentication');
var user = require('./user');

module.exports = function () {
  var app = this;

  app.configure(authentication);
  app.configure(user);
  app.configure(accounts);
  app.configure(generalscript);
  app.configure(clients);
};