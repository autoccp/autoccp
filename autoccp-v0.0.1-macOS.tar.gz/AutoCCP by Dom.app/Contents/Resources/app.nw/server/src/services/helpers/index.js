'use strict';

module.exports = function () {
  var app = this;

  var MailService = require('./mailservice')(app);

  app.use('/mails', new MailService());
};