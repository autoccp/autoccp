'use strict';

// src/services/accounts/hooks/format.js
//
// Use this hook to manipulate incoming or outgoing data.
// For more information on hooks see: http://docs.feathersjs.com/hooks/readme.html


module.exports = function (data) {

  return function (hook) {
    var result = {};
    result.data = hook.result;
    hook.result = result;
  };
};