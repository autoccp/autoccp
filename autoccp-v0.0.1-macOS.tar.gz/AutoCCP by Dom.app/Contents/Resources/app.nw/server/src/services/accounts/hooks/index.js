'use strict';

var _validateHook = require('../../../hooks/validateHook');

var _validation = require('../../../utils/validation');

var format = require('./format');

var create = require('./create');
var deleteacc = require('./delete');
var common = require('feathers-hooks-common');

var hooks = require('feathers-hooks');
var auth = require('feathers-authentication').hooks;

var myDebugHook = function myDebugHook(hook) {
  // check to see what is in my hook object after
  // the token was verified.
  console.log(hook);
};

var schemaValidator = {
  username: [_validation.required, (0, _validation.unique)('username')],
  password: [_validation.required],
  pincode: [_validation.required]
};
/* https://github.com/Stoope/react-app/blob/fda114d559c46000bd205bf577275bba29f39d49/api/services/users/hooks.js */

exports.before = {
  all: [//auth.verifyToken(),
    //auth.restrictToAuthenticated()
    //auth.populateUser()
    //myDebugHook
  ],
  find: [],
  get: [],
  create: [
  //validate(schemaValidator),
  //create(),
  function (hook) {
    hook.data.createdAt = new Date();
    hook.data.setUpdatedAt = new Date();
  }],
  update: [common.setUpdatedAt()],
  patch: [common.setUpdatedAt()],
  remove: [
    //deleteacc()
  ]
};
exports.after = {
  all: [format("data")],
  find: [],
  get: [],
  create: [],
  update: [],
  patch: [],
  remove: []
};