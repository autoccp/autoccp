'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = validateHook;

var _validation = require('../utils/validation');

var _feathersErrors = require('feathers-errors');

var _feathersErrors2 = _interopRequireDefault(_feathersErrors);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function validateHook(schema) {
  return function (hook) {
    // eslint-disable-line func-names
    return (0, _validation.createValidatorPromise)(schema, { service: this, hook: hook })(hook.data).then(function () {
      return hook;
    }).catch(function (errorsValidation) {
      if (Object.keys(errorsValidation).length) {
        throw new _feathersErrors2.default.BadRequest('Validation failed', errorsValidation);
      }
    });
  };
}