'use strict';

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _isPromise = require('is-promise');

var _isPromise2 = _interopRequireDefault(_isPromise);

var _validations = require('./validations');

var validation = _interopRequireWildcard(_validations);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function createValidatorPromise(rules, params) {
  return function () {
    var data = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

    var errors = validation.createValidator(rules, params)(data);

    var myResolve = function myResolve(key) {
      return function (value) {
        return { value: value, status: 'resolved', key: key };
      };
    };
    var myReject = function myReject(key) {
      return function (err) {
        return { err: err, status: 'rejected', key: key };
      };
    };

    return Promise.all(Object.keys(errors).map(function (error) {
      return (0, _isPromise2.default)(errors[error]) ? errors[error].then(myResolve(error)).catch(myReject(error)) : myReject(error)(errors[error]);
    })).then(function (results) {
      var ret = {};
      results.filter(function (x) {
        return x.status === 'rejected';
      }).map(function (x) {
        ret[x.key] = x.err;
        return x;
      });
      return Object.keys(ret).length ? Promise.reject(ret) : Promise.resolve(data);
    });
  };
}

function unique(field) {
  return function (value, data, _ref) {
    var service = _ref.service;
    return service.find({ query: _defineProperty({}, field, value) }).then(function (result) {
      if (result.total !== 0) {
        return Promise.reject('Already exist');
      }
    });
  };
}

module.exports = _extends({}, validation, {
  unique: unique,
  createValidatorPromise: createValidatorPromise
});