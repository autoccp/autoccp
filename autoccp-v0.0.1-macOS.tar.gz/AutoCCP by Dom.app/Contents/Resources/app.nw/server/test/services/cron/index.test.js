'use strict';

var assert = require('assert');
var app = require('../../../src/app');

describe('cron service', function () {
  it('registered the crons service', function () {
    assert.ok(app.service('crons'));
  });
});