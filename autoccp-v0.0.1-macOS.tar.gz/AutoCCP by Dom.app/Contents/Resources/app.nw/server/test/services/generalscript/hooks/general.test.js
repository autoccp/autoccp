'use strict';

var assert = require('assert');
var general = require('../../../../src/services/generalscripts/hooks/general.js');

describe('generalscripts general hook', function () {
  it('hook can be used', function () {
    var mockHook = {
      type: 'before',
      app: {},
      params: {},
      result: {},
      data: {}
    };

    general()(mockHook);

    assert.ok(mockHook.general);
  });
});