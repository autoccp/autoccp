'use strict';

var assert = require('assert');
var create = require('../../../../src/services/accounts/hooks/create.js');

describe('accounts create hook', function () {
  it('hook can be used', function () {
    var mockHook = {
      type: 'before',
      app: {},
      params: {},
      result: {},
      data: {}
    };

    create()(mockHook);

    assert.ok(mockHook.create);
  });
});