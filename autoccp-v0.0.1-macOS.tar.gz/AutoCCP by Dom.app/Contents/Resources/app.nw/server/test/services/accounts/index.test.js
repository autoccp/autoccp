'use strict';

var assert = require('assert');
var app = require('../../../src/app');

describe('accounts service', function () {
  it('registered the accounts service', function () {
    assert.ok(app.service('accounts'));
  });
});