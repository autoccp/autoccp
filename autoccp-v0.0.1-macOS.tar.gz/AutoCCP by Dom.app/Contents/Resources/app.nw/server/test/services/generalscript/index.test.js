'use strict';

var assert = require('assert');
var app = require('../../../src/app');

describe('generalscript service', function () {
  it('registered the generalscripts service', function () {
    assert.ok(app.service('generalscripts'));
  });
});