'use strict';

var assert = require('assert');
var format = require('../../../../src/services/accounts/hooks/format.js');

describe('accounts format hook', function () {
  it('hook can be used', function () {
    var mockHook = {
      type: 'after',
      app: {},
      params: {},
      result: {},
      data: {}
    };

    format()(mockHook);

    assert.ok(mockHook.format);
  });
});