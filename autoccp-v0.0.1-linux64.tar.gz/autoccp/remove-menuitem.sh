#!/usr/bin/env bash

xdg-desktop-menu uninstall autoccp.desktop
xdg-icon-resource uninstall --size  16 autoccp
xdg-icon-resource uninstall --size  32 autoccp
xdg-icon-resource uninstall --size  48 autoccp
xdg-icon-resource uninstall --size  64 autoccp
xdg-icon-resource uninstall --size 128 autoccp
xdg-icon-resource uninstall --size 256 autoccp
