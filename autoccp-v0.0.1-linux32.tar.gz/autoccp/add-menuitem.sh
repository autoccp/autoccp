#!/usr/bin/env bash

DIR=$(readlink -f "${0}")
HERE=$(dirname "${DIR}")

TMP=$(mktemp --directory)
DESKTOP="${TMP}/autoccp.desktop"

cat << EOF > "${DESKTOP}"
[Desktop Entry]
Type=Application
Name=AutoCCP
GenericName=AutoCCP
Comment=AutoCCP
Keywords=auto;autoccp;
Categories=AudioVideo;
Exec=${HERE}/start.sh
Icon=autoccp
EOF

xdg-desktop-menu install "${DESKTOP}"
xdg-icon-resource install --size 16 "${HERE}/icons/icon-16.png" autoccp
xdg-icon-resource install --size 32 "${HERE}/icons/icon-32.png" autoccp
xdg-icon-resource install --size 48 "${HERE}/icons/icon-48.png" autoccp
xdg-icon-resource install --size 64 "${HERE}/icons/icon-64.png" autoccp
xdg-icon-resource install --size 128 "${HERE}/icons/icon-128.png" autoccp
xdg-icon-resource install --size 256 "${HERE}/icons/icon-256.png" autoccp

rm "${DESKTOP}"
rm -R "${TMP}"
